from aiogram.types import Message
from aiogram import Bot

async def check(msg: Message, bot: Bot):
    text = msg.text
    if not (text.startswith("bot") or text.startswith("бот")):
        return
    command = text.split(None, 1)[1]
    match command.split(None, 1)[0]:
        case "название" | "name":
            await bot.set_my_name(command.split(None, 1)[1])
        case "описание" | "description":
            await bot.set_my_description(command.split("\n", 1)[1])

