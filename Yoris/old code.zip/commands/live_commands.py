from aiogram.types import Message

async def check(msg: Message):
    match msg.text:
        case "пинг":
            await msg.answer("понг")
        case "бот":
            await msg.answer("на месте")
        case "пиу":
            await msg.answer("пау")
        case "кинг":
            await msg.answer("конг")
