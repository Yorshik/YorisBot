from aiogram import Bot
from aiogram import types
from aiogram import enums


async def check(msg: types.Message, bot: Bot):
    if msg.text == "тест разворачиваемого списка":
        text = "\n".join(f"{i} Хм" for i in range(20))
        await msg.answer(text, entities=[types.MessageEntity(type="expandable_blockquote", offset=0, length=len(text))])
