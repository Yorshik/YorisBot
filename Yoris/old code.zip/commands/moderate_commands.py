from aiogram import Bot
from aiogram.types import Message


async def check(msg: Message, bot: Bot):
    if "смс" in msg.text or "sms" in msg.text:
        await check_sms(msg, bot)
    if "повысить" in msg.text or "promote" in msg.text:
        await check_promote(msg, bot)


async def check_sms(msg: Message, bot: Bot):
    text = msg.text
    if text.startswith("-"):
        parts = text[1:].split(" ", 1)
        amount = parts[1] if len(parts) > 1 else None
        if not amount:
            await msg.reply_to_message.delete()
            await msg.delete()
            return
        if amount.isdigit():
            amount = int(amount) + 1
            sms_id = msg.message_id
            chat_id = msg.chat.id
            c = 0
            while c != amount:
                try:
                    await bot.delete_message(chat_id, sms_id - c)
                except Exception as e:
                    # await msg.answer("Хз че такое, вот ошибка - {e}, а вот ид - {sms}".format(e=e, sms=sms_id-c))
                    amount += 1
                c += 1


async def check_promote(msg: Message, bot: Bot):
