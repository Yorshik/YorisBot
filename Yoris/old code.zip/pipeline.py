from aiogram import Bot
from aiogram.types import Message

from commands import live_commands
from commands import moderate_commands
from commands import bot_commands
from commands import test_commands

from middlewares import log_middleware
from middlewares import stats_middleware
from middlewares import update_middleware

from utils import database_manager


async def process_message(msg: Message, bot: Bot):
    await update_middleware.update(msg, bot)
    await stats_middleware.update(msg, bot)

    text = msg.text
    prefixes = await database_manager.get_prefixes(msg.chat.id)
    has_prefix = False
    for prefix in prefixes:
        if text.startswith(prefix):
            text = text[len(prefix):]
            has_prefix = True
            break
    require_prefix = database_manager.command_require_prefix(msg.chat.id, text)
    has_prefix = has_prefix
    if require_prefix and not has_prefix:
        return

    await live_commands.check(msg)
    await moderate_commands.check(msg, bot)
    await bot_commands.check(msg, bot)
    await test_commands.check(msg, bot)
