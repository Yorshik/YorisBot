from aiogram import Bot
from aiogram.types import Message

import database_manager


async def update_middleware(msg: Message, bot: Bot):
    activity = await database_manager.add_stats(msg, bot)
    print(f"NEW ACTIVITY:{activity.user_id}, {activity.chat_id}")
