from aiogram.types import Message
from aiogram import Bot
from utils import database_manager


async def update(msg: Message, bot: Bot):
    await database_manager.update_chat(msg, bot)
    await database_manager.update_user(msg, bot)
    await database_manager.update_chat_member(msg, bot)
    await database_manager.add_stats(msg, bot)